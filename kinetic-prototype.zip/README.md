# Kinetic Network - Patient History Sharing Incentive System

## Overview
This project is a functional prototype for the **Kinetic Network**, a reciprocity-based patient history sharing system designed for physiotherapy clinics. It demonstrates an incentive model where clinics earn "Credits" by sharing high-quality structured data (diagnosis, objective history, PROMs) and spend those credits to retrieve patient history from other network members.

The goal is to solve the "cold start" problem in health data exchange by gamifying contribution and ensuring data quality through a tiered scoring system.

## 🚀 How to Run (Easy Method)

**Prerequisite:** You must have **Node.js** installed on your computer.

### For Windows Users:
1. Unzip the folder.
2. Double-click the file named **`start-windows.bat`**.
3. A window will appear installing the necessary files. Once finished, your browser will open the app automatically.

### For Mac Users:
1. Unzip the folder.
2. Double-click the file named **`start-mac.command`**.
   * *Note: If Mac security prevents it from opening, right-click the file, select "Open", and confirm.*
3. A terminal window will appear installing the necessary files. Once finished, your browser will open the app automatically.

---

## 💻 Manual Installation (Developer Method)

If you prefer using the command line manually:

1. Open your terminal in the project directory.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## 🏗️ Project Structure

- **`App.tsx`**: Main application router and layout wrapper.
- **`context/AppContext.tsx`**: Manages global state (User tokens, Participation status, Network records).
- **`components/`**:
  - **`ShareRecord.tsx`**: The core contribution flow. Calculates "Quality Score" based on selected data attributes.
  - **`CreditLedger.tsx`**: A transactional view of credits earned vs. spent.
  - **`NetworkInsights.tsx`**: Data visualization dashboard showing network trends.
  - **`RequestRecords.tsx`**: Simulation of requesting data from non-partnered clinics.
- **`types.ts`**: TypeScript definitions for Clinical Records, Transactions, and User State.

## 🌟 Key Features to Test

1. **The Incentive Loop**: 
   - Go to **Settings** and "Opt-in" to the network.
   - Go to **Share Record**, select a patient, and toggle different data attributes (Diagnosis, Subjective, etc.) to see how the "Quality Score" and "Credit Multiplier" change in real-time.
   
2. **Data Retrieval**:
   - Go to **Browse Network**.
   - Attempt to view a record. If you have insufficient credits, the system will prompt you to share data first.
   
3. **Network Insights**:
   - Visit the **Network Insights** tab to view mock aggregate data visualization using Recharts.

## Tech Stack
- **Framework**: React 18 (Vite)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Charts**: Recharts

---
*Submitted as part of the Heidi Health application challenge.*
